package com.example.jeeto360

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
